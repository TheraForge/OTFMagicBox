#!/bin/bash

set -e  # Exit immediately if a command exits with a non-zero status

###=== CONFIG ===###
REPO_URL="https://github.com/TheraForge/OTFMagicBox.git"
REPO_NAME="OTFMagicBox"

###=== FUNCTIONS ===###

log() {
  echo -e "\033[1;34m[INFO]\033[0m $1"
}

warn() {
  echo -e "\033[1;33m[WARN]\033[0m $1"
}

error() {
  echo -e "\033[1;31m[ERROR]\033[0m $1" >&2
}

check_command() {
  if ! command -v "$1" &> /dev/null; then
    return 1
  fi
  return 0
}

run_or_fail() {
  "$@" || { error "Command failed: $*"; exit 1; }
}

###=== SCRIPT ===###

log "🔧 Starting MagicBox setup..."

# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
log "📂 Script is located in: $SCRIPT_DIR"

# Check for Xcode CLI Tools
if ! xcode-select -p &> /dev/null; then
  log "📦 Installing Xcode Command Line Tools..."
  xcode-select --install
  log "⏳ Waiting for Xcode Command Line Tools to finish installing..."
  until xcode-select -p &> /dev/null; do sleep 5; done
else
  log "✅ Xcode Command Line Tools already installed."
fi

# Install Homebrew
if ! check_command brew; then
  log "📦 Installing Homebrew..."
  run_or_fail /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

  # Add Homebrew to PATH for current script session
  eval "$(/opt/homebrew/bin/brew shellenv)"
else
  log "✅ Homebrew already installed."
fi

# Install Git LFS
if ! check_command git-lfs; then
  log "📦 Installing Git LFS..."
  run_or_fail brew install git-lfs
else
  log "✅ Git LFS already installed."
fi

# Install CocoaPods
if ! check_command pod; then
  log "📦 Installing CocoaPods via Homebrew..."
  run_or_fail brew install cocoapods
else
  log "✅ CocoaPods already installed."
fi

# Move to script's directory
cd "$SCRIPT_DIR" || { error "Failed to navigate to script directory."; exit 1; }

# Clone repo if not already present
if [ ! -d "$REPO_NAME" ]; then
  log "📁 Cloning MagicBox repository into $SCRIPT_DIR..."
  run_or_fail git clone "$REPO_URL"
else
  warn "Repository already exists at $SCRIPT_DIR/$REPO_NAME. Skipping clone."
fi

cd "$REPO_NAME" || { error "Failed to navigate to project directory."; exit 1; }

# Git LFS initialization
log "🔄 Initializing Git LFS..."
run_or_fail git lfs install
run_or_fail git lfs pull

# Install CocoaPods dependencies
log "📦 Installing project dependencies with CocoaPods..."
run_or_fail pod install

# Open in Xcode
log "🚀 Opening the project in Xcode..."
open *.xcworkspace || { error "Failed to open Xcode workspace."; exit 1; }

log "🎉 MagicBox installation completed successfully!"
