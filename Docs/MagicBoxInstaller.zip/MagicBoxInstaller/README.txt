📦 MagicBox App Installer (macOS)

This folder includes everything needed to install the MagicBox App.

🛠 How to run the installer:

👉 EASIEST WAY (Recommended):
1. Right-click (or Control + click) the “MagicBoxInstaller” folder.
2. Choose **"New Terminal at Folder"** from the menu.
3. In the Terminal window that opens, run:
   bash install_magicbox.sh

✅ That’s it — just follow the instructions shown in the Terminal.

---

💻 ALTERNATE WAY (If "New Terminal at Folder" isn’t available):

1. Open the Terminal app:
   - Press `Cmd + Space`, type "Terminal", and press Enter

2. In Terminal, navigate to this folder.
   You can do that by typing `cd` and dragging this folder into the Terminal window:
   Example: cd /Users/yourname/Downloads/MagicBoxInstaller

3. Press Enter, then run:
   bash install_magicbox.sh

---

☑️ What this script will do:
- Install required tools (Xcode CLI tools, Homebrew, Git LFS, CocoaPods)
- Clone the MagicBox GitHub repository into this folder
- Set up the project dependencies
- Open the project in Xcode

📂 Where does it install?
Everything will be set up right here in this folder — clean and simple.

💡 Notes:
- Make sure you're connected to the internet during installation
- You may be asked to enter your Mac password (for installing system tools)
- The setup may take a few minutes depending on your internet speed

📥 Having issues?
Take a screenshot of any error and send it to your team lead or support contact.

🚀 Happy building!